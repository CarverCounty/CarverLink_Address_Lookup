#Author:
#Date:
#Last Update:

import arcpy, datetime, os, sys, random

### Import Carver County custom tools
sys.path.append(r"\\ch_gis\GISData\Tasks\Scripts\SitePackage")

theFC = r"Z:\Applications\External_Apps\embedded_apps\carverLink\DataFiles\Data-Upload_20230627.gdb/AddressPoints"
if (len(sys.argv) >1):
    theFC = str(sys.argv[1])

try:
    print("Starting!")

    outFC = "in_memory/TempFC"
    arcpy.CopyFeatures_management(theFC,outFC)
    finalFC = theFC+"_{}".format(random.randint(1,2132312132))

    tmpDict = dict()
    appendList = []
    dirList = ["north","south","east","west","northeast","southeast","northwest","southwest","n","s","e","w","ne","nw","se","sw"]

    def abbreviationDirection(inWord):
        return inWord.lower().replace("northeast,","NE,").replace("northwest,","NW,").replace("southeast,","SE,").replace("southwest,","SW,").replace("north,","N,").replace("west,","W,").replace("east,","E,").replace("south,","S,")

    theFieldList = ['SITEADDRESS','USPS_PLACE','x','y','Info',"Shape@"]
    with arcpy.da.SearchCursor(outFC, theFieldList) as cursor:
        for row in cursor:
            iSite = row[0]
            iCity = row[1]

            iX = row[2]
            iY = row[3]
            iZone = row[4]
            iShape = row[5]

            theBonus = ""

            for iBonus in ["APARTMENT","UNIT","SUITE","BUILDING"]:
                if (theBonus==""):
                    if (" {} ".format(iBonus.lower()) in iSite.lower()):
                        theIndex = iSite.lower().index(" {} ".format(iBonus.lower()))
                        theBonus = iSite[theIndex:]
                        iSite = iSite[0:theIndex]
                    else:
                        if ((" "+iBonus.lower()) in iSite.lower()):
                            if (iSite.lower()[(0-len(iBonus)-1):] == iBonus.lower()):
                                theBonus = iSite[0-len(iBonus)-1:]
                                iSite = iSite[0:len(iSite)-len(theBonus)]


            iKey = "{}, {}".format(iSite,iCity)

            tmpDict[iKey] = [iSite,iCity,iX,iY,iZone,iShape]

            for iDir in dirList:
                tmpDir = " {}, ".format(iDir)
                if (tmpDir in iKey.lower()):
##                    print("Going to Split: {}".format(iKey))

                    wordArray = iSite.split()
                    newAddy = wordArray[0]
                    newAddyAbbr = wordArray[0]
                    theFirstWordIndex = 1
                    if (wordArray[1] == "1/2"):
                        newAddy+=" 1/2 "
                        newAddyAbbr+=" 1/2 "
                        theFirstWordIndex = 2


                    tmpKey = abbreviationDirection(iKey).lower()
                    if (tmpKey <> iKey.lower()):

##                        print(tmpKey)
##                        print(iKey)
##                        print(iSite[0:len(iSite)-len(iSite.split()[-1])])
##                        print(abbreviationDirection(iSite.split(" ")[-1:][0]+",").upper().replace("  "," ").replace(",",""))
                        iSite = (iSite[0:len(iSite)-len(iSite.split()[-1])]+" "+(abbreviationDirection(iSite.split(" ")[-1:][0]+",").upper().replace(",",""))).replace("  "," ")
                        appendList.append([iSite+theBonus,iCity,iX,iY,iZone,iShape])

                    newAddy+=" "+wordArray[len(wordArray) - 1]+" "+" ".join(wordArray[theFirstWordIndex:len(wordArray) - 1])+theBonus
                    newAddyAbbr += " "+abbreviationDirection(wordArray[len(wordArray) - 1]+",").replace(",","")+" "+" ".join(wordArray[theFirstWordIndex:len(wordArray) - 1])+theBonus
                    appendList.append([newAddy,iCity,iX,iY,iZone,iShape])
                    appendList.append([newAddyAbbr,iCity,iX,iY,iZone,iShape])


    insertCursor = arcpy.da.InsertCursor(outFC,theFieldList)
    for iAppendRec in appendList:
        iTmpSite = iAppendRec[0].replace("  "," ")
        iTmpcity = iAppendRec[1]
        iTmpKey = "{}, {}".format(iTmpSite,iTmpcity)

        if not (tmpDict.has_key(iTmpKey)):
            insertCursor.insertRow((iTmpSite,iAppendRec[1],iAppendRec[2],iAppendRec[3],iAppendRec[4],iAppendRec[5]))
    del insertCursor

    print("Output: {}".format(finalFC))
    arcpy.CopyFeatures_management(outFC,finalFC)


except Exception as e:
    hadSuccess = False
    print(str(e.message))


print("Done!")

